import Style from './App.css';
import React, { Component } from 'react';
const TodoComponent = {
  width: "300px",
  margin: "30px auto",
  color:"white",
  minHeight: "200px",
  boxSizing: "border-box"
 }
 const Header = {
  padding: "10px 10px",
  textAlign: "left",
  color: "white",
  fontSize: "16px"
 }
 const n={
  textAlign: "center",
  margin: "30px auto",
 }
 const m={
  textAlign: "center",
  margin: "10px auto",
 }
 const bg={
   background:"black",
  /* Set up proportionate scaling */
  top: 0,
  left: 0,
  color:"white",
 }
class Main extends Component {
  

  render() {
    return (
      <body >
      <div >
  
              <div style={TodoComponent}>
        <h1 style={n}>           Add Product          </h1>
        <form onSubmit={(event) => {
          event.preventDefault()
          const name = this.productName.value
          const Web3Utils = require('web3-utils');
          const price = Web3Utils.toWei(this.productPrice.value.toString(), 'Ether')
          this.props.createproduct(name, price)
        }}>
          <div >
            <input
              id="productName"
              type="text"
              ref={(input) => { this.productName = input }}
              className="form-control"
              placeholder="Product Name"
              required />
          </div>
          <div >
            <input
              id="productPrice"
              type="text"
              ref={(input) => { this.productPrice = input }}
              className="form-control"
              placeholder="Product Price"
              required />
          </div>
          <div style={m}>
          <button style={m} type="submit" className="btn btn-primary">Add Product</button>
          </div>
        </form>
        </div>
        <p> </p>
        <div style={Header}>
        <h2>Buy Product</h2>
        <table className="table" style={Header}>
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Price</th>
              <th scope="col">Owner</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody id="productList">
          { this.props.products.map((product, key) => {
  return(
    <tr key={key}>
      <th scope="row">{product.id.toString()}</th>
      <td>{product.name}</td>
      <td>{
      window.web3.utils.fromWei(product.price.toString(), 'Ether')} Eth</td>
      <td>{product.owner}</td>
      <td>
        { !product.purchased
          ? <button
              name={product.id}
              value={product.price}
              onClick={(event) => {
                this.props.purchaseproduct(event.target.name, event.target.value)
              }}
            >
              Buy
            </button>
          : null
        }
        </td>
    </tr>
    
  )
})}
          </tbody>
        </table>
        </div>
        </div>
        </body>

      
    );
  }
}

export default Main;